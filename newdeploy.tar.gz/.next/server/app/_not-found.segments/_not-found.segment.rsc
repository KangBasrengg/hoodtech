1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/3xm51qzcyrk6k.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/3xm51qzcyrk6k.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"JvQX5sa0F3ZhvmQI17_m5"}
