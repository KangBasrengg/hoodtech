var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0nojrj_.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_1-lsc8h.js")
R.m(72755)
module.exports=R.m(72755).exports
