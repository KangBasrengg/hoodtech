globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/JvQX5sa0F3ZhvmQI17_m5/_buildManifest.js",
    "static/JvQX5sa0F3ZhvmQI17_m5/_ssgManifest.js",
    "static/JvQX5sa0F3ZhvmQI17_m5/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3-5k80pt3ds20.js",
    "static/chunks/15orcrkp-_9ct.js",
    "static/chunks/1upe53-127sm4.js",
    "static/chunks/2-5nk792mwq2y.js",
    "static/chunks/turbopack-3qfaocn7hhyqy.js"
  ]
};
