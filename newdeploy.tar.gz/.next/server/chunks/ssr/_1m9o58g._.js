module.exports=[24132,a=>{a.v("/_next/static/media/MuhammadNurilHuda.3xw1kl11qbbva.jpg"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},33354,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}}];

//# sourceMappingURL=_1m9o58g._.js.map